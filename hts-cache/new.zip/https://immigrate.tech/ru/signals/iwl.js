<!DOCTYPE html>
<html lang="ru">
<head>

            <!-- Google Tag Manager -->
        <script>(function(w, d, s, l, i) {
                w[l] = w[l] || []
                w[l].push({
                    'gtm.start':
                        new Date().getTime(), event: 'gtm.js',
                })
                var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''
                j.async = true
                j.src =
                    'https://www.googletagmanager.com/gtm.js?id=' + i + dl
                f.parentNode.insertBefore(j, f)
            })(window, document, 'script', 'dataLayer', 'GTM-WN8Z3VT')
        </script>
        <!-- End Google Tag Manager -->
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-172930168-1"></script>
        <script>
            window.dataLayer = window.dataLayer || []

            function gtag() {dataLayer.push(arguments)}

            gtag('js', new Date())

            gtag('config', 'UA-172930168-1')
        </script>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Not Found (#404)</title>

            <!-- Facebook Pixel Code -->
        <script>
            !function(f, b, e, v, n, t, s) {
                if (f.fbq) return
                n = f.fbq = function() {
                    n.callMethod ?
                        n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                }
                if (!f._fbq) f._fbq = n
                n.push = n
                n.loaded = !0
                n.version = '2.0'
                n.queue = []
                t = b.createElement(e)
                t.async = !0
                t.src = v
                s = b.getElementsByTagName(e)[0]
                s.parentNode.insertBefore(t, s)
            }(window, document, 'script',
                'https://connect.facebook.net/en_US/fbevents.js')
            fbq('init', '706660799898559')
            fbq('track', 'PageView')
        </script>
        <noscript>
            <img height="1"
                 width="1"
                 style="display:none"
                 src="https://www.facebook.com/tr?id=706660799898559&ev=PageView&noscript=1"
                 alt=""
            />
        </noscript>
        <!-- End Facebook Pixel Code -->
    
    <meta name="csrf-param" content="_csrf-frontend">
<meta name="csrf-token" content="e-0Et0uBR19cTex3TjD857BXmIHNVjYII8ZUQi_-K_QRtD2HBu8fGzM-oC0rWJiI0g7u6boeREZQoj4hX7lhrQ==">

<link href="/assets/7765187a/css/bootstrap.css" rel="stylesheet">
<link href="/site.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&amp;display=swap" rel="stylesheet">
<link href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" rel="stylesheet">
<style>    #cookie-agree-banner {
            position: fixed;
            left: 0;
            bottom: 0;
            display: block;
            padding: 2rem;
            width: 100%;
            background-color: rgba(14, 14, 14, 0.95);
            z-index: 3000000000;
            color: #fff;
            font-size: 0.9rem;
        }
        #cookie-agree-banner a {
            color: white;
        }
        #cookie-agree-banner a:hover {
            color: #5f90ef;
        }
        #cookie-agree-banner .cookie-agree-banner__text {
            display: inline-block;
        }
        #cookie-agree-banner .cookie-agree-banner__button {
            display: inline-block;
            padding: 0.4rem 1rem;
            margin-top: 1rem;
            border-radius: 2rem;
            background-color: #13992d;
            color: #fff;
            text-decoration: none;
            text-align: center;
            font-weight: bold;
            transition: background-color .3s;
        }
        #cookie-agree-banner .cookie-agree-banner__button:hover {
            cursor: pointer;
            background-color: #18c139;
        }</style>
    
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Google Tag Manager (noscript) -->
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WN8Z3VT" height="0" width="0"
                style="display:none;visibility:hidden"></iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div id="cookie-agree-banner" class="cookie-agree-banner">
    <span class="cookie-agree-banner__text">
        By using our website you accept our cookies and cookie policy. Our service uses cookies to personalize content,
        advirtisements, to allow us to analyze traffic and enable social media features. The information about your use
        of our website is shared with our social media, advertising and analytics providers.
        <a href="/privacy-policy">Privacy Policy</a>
    </span>
    <span class="cookie-agree-banner__button">
        I agree
    </span>
</div>

<div class="offcanvas-overlay"></div>

<header class="header">

    <a class="navbar-brand" href="/">
        <div class="logo">
            <img class="logo__image" src="/img/logo.png" alt="" loading="lazy" width="70" height="62">
            <span class="logo__label d-none d-sm-block">immigrate.tech</span>
        </div>
    </a>

    <nav id="main-menu"></nav>

    <div class="personal-block">
                    <a class="personal-block__item" href="/ru/login">
                <i class="fa fa-sign-in-alt"></i> Войти            </a>
        
        <div class="dropdown">
                        <div class="personal-block__item dropdown-toggle" id="language-dropdown-button" data-toggle="dropdown">
                <span class="d-inline d-sm-none text-uppercase">ru</span>
                <span class="d-none d-sm-inline">Русский</span>
            </div>
            <div class="dropdown-menu dropdown-menu-right rounded-0" aria-labelledby="language-dropdown-button">
                                    <a class="dropdown-item" href="/en/site/error">
                        English                    </a>
                                    <a class="dropdown-item" href="/es/site/error">
                        Español                    </a>
                                    <a class="dropdown-item" href="/zh/site/error">
                        简体中文(中国)                    </a>
                            </div>
        </div>
        <div class="main-navbar__btn-burger">
            <div class="main-navbar__btn-burger-icon"></div>
        </div>
    </div>
</header>

<div class="main-navbar">
    <nav class="main-navbar__nav">
                    
                <div class="main-navbar__item" data-priority="100">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/certificate-of-citizenship">Гражданство США</a>

                                            </div>

                    
                </div>
            
                <div class="main-navbar__item" data-priority="100">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/green-card">Грин-карты</a>

                                                    <div class="main-navbar__dropdown-toggler"></div>
                                            </div>

                                            <div class="main-navbar__dropdown">
                                                            <a href="/ru/green-card/family-based-green-card">Семейная Грин-карта (форма I-130 и I-485)</a>
                                                            <a href="/ru/green-card/marriage-green-card">Грин-карта для супружеских пар (форма I-130 и I-485)</a>
                                                            <a href="/ru/green-card/adjustment-of-status">Корректировка статуса (форма I-485)</a>
                                                            <a href="/ru/green-card/employment-based-green-card">Рабочая Грин-карта (форма I-485 и I-140)</a>
                                                            <a href="/ru/green-card/diversity-visa-program-green-card-lottery">Лотерея Грин-карт (форма DS-260)</a>
                                                            <a href="/ru/green-card/green-card-replacement">Замена Грин-карты (форма I-90)</a>
                                                            <a href="/ru/green-card/green-card-renewal">Продление Грин-карты (форма I-90)</a>
                                                            <a href="/ru/green-card/employment-authorization">Разрешение на работу (форма I-765)</a>
                                                            <a href="/ru/green-card/advance-parole">Разрешение на обратный въезд (Форма I-131)</a>
                                                            <a href="/ru/green-card/refugees-and-asylum">Политическое убежище</a>
                                                    </div>
                    
                </div>
            
                <div class="main-navbar__item" data-priority="100">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/u-s-visas">Визы США</a>

                                                    <div class="main-navbar__dropdown-toggler"></div>
                                            </div>

                                            <div class="main-navbar__dropdown">
                                                            <a href="/ru/u-s-visas/business-visitor-tourist-visa-b1-b2">В1/B2 Деловая / Туристическая виза (форма DS-160)</a>
                                                            <a href="/ru/u-s-visas/student-visa-f-1">F-1 Студенческая виза (форма DS-160)</a>
                                                            <a href="/ru/u-s-visas/student-visa-m-1">M-1 Виза для профессионально-технических студентов (форма DS-160)</a>
                                                            <a href="/ru/u-s-visas/fiance-visa-k-1">K-1 Свадебная виза (форма I-129)</a>
                                                            <a href="/ru/u-s-visas/temporary-work-visa-h1b">H-1B Рабочая виза (форма I-129)</a>
                                                            <a href="/ru/u-s-visas/intracompany-transferees-visa-l1">L-1 Виза для перевода сотрудника внутри компании (форма I-129)</a>
                                                            <a href="/ru/u-s-visas/visa-for-persons-with-extraordinary-ability-o1">O-1 Виза для лиц с выдающимися способностями (форма I-129)</a>
                                                            <a href="/ru/u-s-visas/visa-for-foreign-investors">EB-5 Виза для иностранных инвесторов</a>
                                                            <a href="/ru/u-s-visas/treaty-investors-and-employees">Виза для иностранных инвесторов E2</a>
                                                    </div>
                    
                </div>
            
                <div class="main-navbar__item" data-priority="100">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/removal-and-deportation">Депортация</a>

                                                    <div class="main-navbar__dropdown-toggler"></div>
                                            </div>

                                            <div class="main-navbar__dropdown">
                                                            <a href="/ru/removal-and-deportation/your-rights">Ваши права</a>
                                                            <a href="/ru/removal-and-deportation/how-to-behave-with-ice-agents">Ваши действия в присутствии агентов ICE</a>
                                                            <a href="/ru/removal-and-deportation/for-friends-and-family">Информация для семьи и близких</a>
                                                            <a href="/ru/removal-and-deportation/getting-an-attorney">Поиск адвоката</a>
                                                    </div>
                    
                </div>
                                
                <div class="main-navbar__item" data-priority="90">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/fees">Цены</a>

                                            </div>

                    
                </div>
                                
                <div class="main-navbar__item" data-priority="80">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/contacts">Контакты</a>

                                            </div>

                    
                </div>
                                
                <div class="main-navbar__item" data-priority="70">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/reviews">Отзывы</a>

                                            </div>

                    
                </div>
                                
                <div class="main-navbar__item" data-priority="60">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/knowledge-center">Новости</a>

                                            </div>

                    
                </div>
                                
                <div class="main-navbar__item" data-priority="0">

                    <div class="main-navbar__link-wrapper">
                        <a class="main-navbar__link" href="/ru/about-us">О нас</a>

                                            </div>

                    
                </div>
                        </nav>
</div>

<main>
    <div class="container">
                    </div>
    <div class="container my-5">

    <h1>Not Found (#404)</h1>

    <div class="alert alert-danger">
        Страница не найдена.    </div>

    <p>
        Вышеупомянутая ошибка произошла во время обработки вашего запроса веб-сервером.    </p>
    <p>
        Свяжитесь с нами, если вы считаете, что это ошибка сервера. Спасибо.     </p>

</div>
</main>

<footer class="footer mt-auto py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-sm">
                <h3>Immigration Services</h3>
                <ul class="menu">
                    <li class="item-205 alias-parent-active"><a href="/green-card">Green Card</a></li>
                    <li class="item-206"><a href="/u-s-visas">U.S. Visas</a></li>
                    <li class="item-204"><a href="/certificate-of-citizenship">U.S. Citizenship</a></li>
                    <li class="item-204"><a href="/removal-and-deportation">Removal & Deportation</a></li>
                </ul>
            </div>
            <div class="col-sm">

                <h3>Contact Us</h3>

                <div class="custom">
                    <div class="mb-0">+1.888.866.2416</div>
                    <div class="mb-0">160 S Monaco Parkway, Suite 508,
                        <div class="mb-0">Denver, Colorado 80224<br>
                            <br>
                            <a href="mailto:help@immigrate.tech">help@immigrate.tech</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm d-flex justify-content-center align-items-center mt-5">
                <svg class="footer__social-icon footer__social-icon_disabled" aria-hidden="true" data-prefix="fab"
                     data-icon="twitter" role="img"
                     xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                    <path fill="currentColor"
                          d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path>
                </svg>
                <a href="https://www.facebook.com/immigrate.tech" target="_blank">
                    <svg class="footer__social-icon" aria-hidden="true" data-prefix="fab" data-icon="facebook-f"
                         role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 264 512" data-fa-i2svg="">
                        <path fill="currentColor"
                              d="M76.7 512V283H0v-91h76.7v-71.7C76.7 42.4 124.3 0 193.8 0c33.3 0 61.9 2.5 70.2 3.6V85h-48.2c-37.8 0-45.1 18-45.1 44.3V192H256l-11.7 91h-73.6v229"></path>
                    </svg>
                </a>
                <svg class="footer__social-icon footer__social-icon_disabled" aria-hidden="true" data-prefix="fab"
                     data-icon="linkedin-in"
                     role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                    <path fill="currentColor"
                          d="M100.3 480H7.4V180.9h92.9V480zM53.8 140.1C24.1 140.1 0 115.5 0 85.8 0 56.1 24.1 32 53.8 32c29.7 0 53.8 24.1 53.8 53.8 0 29.7-24.1 54.3-53.8 54.3zM448 480h-92.7V334.4c0-34.7-.7-79.2-48.3-79.2-48.3 0-55.7 37.7-55.7 76.7V480h-92.8V180.9h89.1v40.8h1.3c12.4-23.5 42.7-48.3 87.9-48.3 94 0 111.3 61.9 111.3 142.3V480z"></path>
                </svg>
                <svg class="footer__social-icon footer__social-icon_disabled" aria-hidden="true" data-prefix="fab"
                     data-icon="instagram"
                     role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                    <path fill="currentColor"
                          d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path>
                </svg>
            </div>
        </div>
    </div>
    <hr class="bg-white">
    <div class="container">
        <p>
            2023&nbsp;© immigrate.tech - Immigration Service
        </p>
        <p>
            immigrate.tech (HOVOT SPV I, LLC) is not represented as a law firm and/or a substitute of
            attorney’s advice. immigrate.tech is not affiliated with or endorsed by any government agency,
            including United States Citizenship and Immigration Services (USCIS). All of the immigration forms
            templates with written instructions are available in open access for free at the official
            <a href="https://www.uscis.gov/">USCIS website</a>. Our attorney services are provided
            by&nbsp;affiliate attorneys. Use of the immigrate.tech website and its services is subject to our
            <a href="/privacy-policy">Privacy Policy</a> and <a href="/terms-of-use">Terms of Use</a>.
        </p>
    </div>

            <script
            src="//code.jivosite.com/widget.js"
            data-jv-id="kzaWYZhXxt"
            async
        >
        </script>
        

</footer>



<div id="modal-contact-form" class="fade modal" role="dialog" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg" role="document">
<div class="modal-content">
<div id="modalHeader" class="modal-header" style="margin-top: 100px;">

<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
</div>
<div class="modal-body">

	<div class="formAlert" style="display: none;"></div>

	<form id="contact-form-modal" action="/ru/contacts/save" method="post">
<input type="hidden" name="_csrf-frontend" value="e-0Et0uBR19cTex3TjD857BXmIHNVjYII8ZUQi_-K_QRtD2HBu8fGzM-oC0rWJiI0g7u6boeREZQoj4hX7lhrQ==">		<div class="form-group field-contactform-name required">
<label for="contactform-name">Ваше имя</label>
<input type="text" id="contactform-name" class="form-control" name="ContactForm[name]" maxlength="100" autofocus aria-required="true">

<div class="invalid-feedback"></div>
</div>		<div class="form-group field-contactform-email required">
<label for="contactform-email">Адрес электронной почты</label>
<input type="text" id="contactform-email" class="form-control" name="ContactForm[email]" maxlength="100" aria-required="true">

<div class="invalid-feedback"></div>
</div>		<div class="form-group field-contactform-phone">
<label for="contactform-phone">Телефон</label>
<input type="text" id="contactform-phone" class="form-control" name="ContactForm[phone]" maxlength="20">

<div class="invalid-feedback"></div>
</div>		<div class="form-group field-contactform-zipcode">
<label for="contactform-zipcode">Почтовый индекс</label>
<input type="text" id="contactform-zipcode" class="form-control" name="ContactForm[zipCode]" maxlength="10">

<div class="invalid-feedback"></div>
</div>		<div class="form-group field-contactform-message required">
<label for="contactform-message">Текст сообщения</label>
<textarea id="contactform-message" class="form-control" name="ContactForm[message]" rows="6" aria-required="true"></textarea>

<div class="invalid-feedback"></div>
</div>		<div class="form-group field-contactform-recaptcha">

<input type="hidden" id="contactform-recaptcha" class="form-control" name="ContactForm[reCaptcha]"><div id="contactform-recaptcha-recaptcha-contact-form-modal" class="g-recaptcha" data-sitekey="6LdB3vAkAAAAAMwbxK2mQ9ZrXw5nGwGj6j30prCv" data-input-id="contactform-recaptcha" data-form-id="contact-form-modal"></div>

<div class="invalid-feedback"></div>
</div>		<div class="form-group">
			<button type="submit" class="btn btn-primary" name="contact-button">Отправить</button>		</div>
	</form>

</div>

</div>
</div>
</div>
<script src="//www.google.com/recaptcha/api.js?hl=ru&amp;render=explicit&amp;onload=recaptchaOnloadCallback" async defer></script>
<script src="/assets/60592873/jquery.js"></script>
<script src="/assets/e34b62d2/yii.js"></script>
<script src="/assets/7765187a/js/bootstrap.bundle.js"></script>
<script src="/site.js"></script>
<script src="/assets/a25e3e2e/jquery.cookie.js"></script>
<script src="/assets/e34b62d2/yii.validation.js"></script>
<script src="/assets/e34b62d2/yii.activeForm.js"></script>
<script>function recaptchaOnloadCallback() {
    "use strict";
    jQuery(".g-recaptcha").each(function () {
        const reCaptcha = jQuery(this);
        if (reCaptcha.data("recaptcha-client-id") === undefined) {
            const recaptchaClientId = grecaptcha.render(reCaptcha.attr("id"), {
                "callback": function (response) {
                    if (reCaptcha.data("form-id") !== "") {
                        jQuery("#" + reCaptcha.data("input-id"), "#" + reCaptcha.data("form-id")).val(response)
                            .trigger("change");
                    } else {
                        jQuery("#" + reCaptcha.data("input-id")).val(response).trigger("change");
                    }

                    if (reCaptcha.attr("data-callback")) {
                        eval("(" + reCaptcha.attr("data-callback") + ")(response)");
                    }
                },
                "expired-callback": function () {
                    if (reCaptcha.data("form-id") !== "") {
                        jQuery("#" + reCaptcha.data("input-id"), "#" + reCaptcha.data("form-id")).val("");
                    } else {
                        jQuery("#" + reCaptcha.data("input-id")).val("");
                    }

                    if (reCaptcha.attr("data-expired-callback")) {
                        eval("(" + reCaptcha.attr("data-expired-callback") + ")()");
                    }
                },
            });
            reCaptcha.data("recaptcha-client-id", recaptchaClientId);
        }
    });
}</script>
<script>jQuery(function ($) {
    const button = $(document.querySelector('#cookie-agree-banner .cookie-agree-banner__button'))
    button.on('click', function() {
        document.getElementById('cookie-agree-banner').style.display = 'none';
        jQuery.cookie('cookie-agree', true, {expires: 1, path: '/'});
    })
    var $form = $('#contact-form-modal');
    var $alert = $('.formAlert');
    $form.on('beforeSubmit', function() {
        $alert.hide();
        var data = $form.serialize();
        $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            data: data,
            success: function (data) {
                console.log(data.message)
                $alert.text(data.message).show();
                $form.reset();
            },
            error: function(jqXHR, errMsg) {
                $alert.text(data.message).show();
            }
         });
         return false; // prevent default submit
    });
jQuery('#contact-form-modal').yiiActiveForm([{"id":"contactform-name","name":"name","container":".field-contactform-name","input":"#contactform-name","error":".invalid-feedback","validate":function (attribute, value, messages, deferred, $form) {yii.validation.required(value, messages, {"message":"Необходимо заполнить «Ваше имя»."});yii.validation.string(value, messages, {"message":"Значение «Ваше имя» должно быть строкой.","max":100,"tooLong":"Значение «Ваше имя» должно содержать максимум 100 символов.","skipOnEmpty":1});}},{"id":"contactform-email","name":"email","container":".field-contactform-email","input":"#contactform-email","error":".invalid-feedback","validate":function (attribute, value, messages, deferred, $form) {yii.validation.required(value, messages, {"message":"Необходимо заполнить «Адрес электронной почты»."});yii.validation.string(value, messages, {"message":"Значение «Адрес электронной почты» должно быть строкой.","max":100,"tooLong":"Значение «Адрес электронной почты» должно содержать максимум 100 символов.","skipOnEmpty":1});yii.validation.email(value, messages, {"pattern":/^[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/,"fullPattern":/^[^@]*<[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?>$/,"allowName":false,"message":"Значение «Адрес электронной почты» не является правильным email адресом.","enableIDN":false,"skipOnEmpty":1});}},{"id":"contactform-phone","name":"phone","container":".field-contactform-phone","input":"#contactform-phone","error":".invalid-feedback","validate":function (attribute, value, messages, deferred, $form) {yii.validation.string(value, messages, {"message":"Значение «Телефон» должно быть строкой.","max":20,"tooLong":"Значение «Телефон» должно содержать максимум 20 символов.","skipOnEmpty":1});}},{"id":"contactform-zipcode","name":"zipCode","container":".field-contactform-zipcode","input":"#contactform-zipcode","error":".invalid-feedback","validate":function (attribute, value, messages, deferred, $form) {yii.validation.string(value, messages, {"message":"Значение «Почтовый индекс» должно быть строкой.","max":10,"tooLong":"Значение «Почтовый индекс» должно содержать максимум 10 символов.","skipOnEmpty":1});}},{"id":"contactform-message","name":"message","container":".field-contactform-message","input":"#contactform-message","error":".invalid-feedback","validate":function (attribute, value, messages, deferred, $form) {yii.validation.required(value, messages, {"message":"Необходимо заполнить «Текст сообщения»."});}},{"id":"contactform-recaptcha","name":"reCaptcha","container":".field-contactform-recaptcha","input":"#contactform-recaptcha","error":".invalid-feedback","validate":function (attribute, value, messages, deferred, $form) {if (!value) {
     messages.push("Пожалуйста, подтвердите, что Вы не бот.");
}}}], {"errorSummary":".alert.alert-danger","errorCssClass":"is-invalid","successCssClass":"is-valid","validationStateOn":"input"});
jQuery('#modal-contact-form').modal({"show":false,"backdrop":"static","keyboard":false});
});</script>
</body>
</html>
